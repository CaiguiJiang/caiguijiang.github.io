---
# Display name
title: Quanyue Song 宋权岳 

# Username (this should match the folder name)
authors:
- QuanyueSong

# Is this the primary user of the site?
superuser: false

# Role/position
role: Ph.D Student

# Organizations/Affiliations
organizations:
- name: Xi'an Jiaotong University
  url: "https://www.xjtu.edu.cn/"

# Short bio (displayed in user profile at end of posts)
bio: My research interests are in video/audio Processing, 3D reconstruction, talking head, digital human and computer vision.

interests:
- Talking head
- Digital human
- Computer vision


education:
  courses:
  - course: PhD in artificial intelligence
    institution: Xi’an Jiaotong University
    year: 2023 --- Present
  - course: BSc in artificial intelligence
    institution: Xi’an Jiaotong University
    year: 2019 --- 2023



# Enter email to display Gravatar (if Gravatar enabled in Config)
# email: "test@test.com"

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
- PhD Students
---
I am a PhD/EngD student at [Institute of Artificial Intelligence and Robotics](http://www.aiar.xjtu.edu.cn/) of [Xi’an Jiaotong University](http://www.xjtu.edu.cn/) in China. I received my B.S. degrees from [Xi’an Jiaotong University](http://www.xjtu.edu.cn/) (XJTU) in 2023. My research interests are in video/audio Processing, 3D reconstruction, talking head, digital human and computer vision. 

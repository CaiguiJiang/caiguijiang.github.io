---
# Display name
title: Chaoyun Wang 王超运 

# Username (this should match the folder name)
authors:
- ChaoyunWang

# Is this the primary user of the site?
superuser: false

# Role/position
role: Ph.D Student

# Organizations/Affiliations
organizations:
- name: Xi'an Jiaotong University
  url: "https://www.xjtu.edu.cn/"

# Short bio (displayed in user profile at end of posts)
bio: My research interests are in geometric modeling, geometry processing, architectural geometry, computer graphics, and computer vision.

interests:
- Artificial Intelligence
- Computer Graphics
- Geometry Processing


education:
  courses:
  - course: PhD in Computer Science
    institution: King Abdullah University of Science and Technology
    year: 2011 --- 2016
  - course: MSc in Pattern Recognition and Intelligent Systems
    institution: Xi’an Jiaotong University
    year: 2008 --- 2011
  - course: BSc in Electronic Engineering
    institution: Xi’an Jiaotong University
    year: 2004 --- 2008



# Enter email to display Gravatar (if Gravatar enabled in Config)
# email: "test@test.com"

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
- Grad Students
---
I am a professor at [Institute of Artificial Intelligence and Robotics](http://www.aiar.xjtu.edu.cn/) of [Xi’an Jiaotong University](http://www.xjtu.edu.cn/) in China. Before that, I worked as a research scientist and Postdoc at [Visual Computing Center](https://cemse.kaust.edu.sa/vcc) (VCC) of [King Abdullah University of Science and Technology](https://www.kaust.edu.sa) (KAUST), [ICSI, UC Berkeley](https://www.icsi.berkeley.edu/icsi/) and [the Max Planck Institute for Informatics](https://www.mpi-inf.mpg.de/home). I obtained my Ph.D. from KAUST under the supervision of [Prof. Dr. Helmut Pottmann](https://www.geometrie.tuwien.ac.at/pottmann/) and [Prof. Dr. Peter Wonka](http://peterwonka.net/). I received my B.S. and M.S. degrees from [Xi’an Jiaotong University](http://www.xjtu.edu.cn/) (XJTU) in 2008 and 2011 respectively. My research interests are in geometric modeling, geometry processing, architectural geometry, computer graphics, and computer vision. 

Personal web：[jiang.gr.xjtu.edu.cn](http://jiang.gr.xjtu.edu.cn)
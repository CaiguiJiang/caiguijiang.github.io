---
# Display name
title: Haoyuan He 何浩源 

# Username (this should match the folder name)
authors:
- HaoyuanHe

# Is this the primary user of the site?
superuser: false

# Role/position
role: MSc Student

# Organizations/Affiliations
organizations:
- name: Xi'an Jiaotong University
  url: "https://www.xjtu.edu.cn/"

# Short bio (displayed in user profile at end of posts)
bio: My research interests are in artificial intelligence, computer graphics, and computer vision.

interests:
- Artificial Intelligence
- Computer Graphics
- Computer Vision


education:
  courses:
  - course: BSc in Computer Science
    institution: Xi’an Jiaotong University
    year: 2020 --- 2024



# Enter email to display Gravatar (if Gravatar enabled in Config)
# email: "test@test.com"

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
- MS Students
---
I am a MSc student in Artificial Intelligence at [Institute of Artificial Intelligence and Robotics](http://www.aiar.xjtu.edu.cn/) of [Xi’an Jiaotong University](http://www.xjtu.edu.cn/), advised by Prof. [Caigui Jiang](http://jiang.gr.xjtu.edu.cn). Before that, I received my B.S. degree from [Xi’an Jiaotong University](http://www.xjtu.edu.cn/) (XJTU) in 2024. My research interests are in artificial intelligence, computer graphics, and computer vision. 

Personal web：[https://github.com/Hyxelife]()